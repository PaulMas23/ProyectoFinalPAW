<form action="./controller/insertAlumnoController.php" method="POST" class="mb-3">
    

    <input type="text" name="matricula" class = "form-control mb-3" placeholder="Matricula">
    <input type="text" class="form-control mb-3" name="nombre" placeholder="Nombre">
    <input type="text" class="form-control mb-3" name="sexo" placeholder="Sexo">
                                
    <input type="submit" class="btn  center btn-primary btn-block" value="Guardar">
</form>
