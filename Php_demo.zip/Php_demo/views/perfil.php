<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css"
    />
<link
    href="https://fonts.googleapis.com/icon?family=Material+Icons"
    rel="stylesheet"
    />
<h2> DATOS PERSONALES </h2>

<div class="container">
    <div class="row">
        <div class="card orange"
             <div class="col s12 m6">
            <div class="card-content">
                <p>
                    Mi nombre es Paul Enrique Mas Qui tengo 22 años y soy alumno de la facultad ingenieria
                    en Sistemas Computacionales.
                </p>
            </div>
        </div>
    </div>
</div>

<hr />

<div class="container">
    <div class="row">
        <div class="col s12 m6">
            <div class="card red">
                <div class="card-content">
                    <div class="card-title">
                        Goals&Motivation
                    </div>
                    <p>
                        Mejorar mis conocimientos en otras areas de la ingeniería y construir un mejor futuro en mi vida.
                    </p>
                </div>
            </div>
        </div>
        <div class="col s12 m6">
            <div class="card black">
                <div class="card-content">
                    <div class="card-title">
                        A day in the life of...
                    </div>
                    <p>
                        Me gusta ayudar a los demas, interactuo con mi familia, siento satisfaccion cuando me salen las cosas bien pero siempre investigo para resolverlas.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="container">
    <div class="row">
        <div class="col s12">
            <div class="card red">
                <div class="card-content">
                    <div class="card-title">
                        ACERCA DE MI
                    </div>
                    

                    <p>
                        Me llamo Paul Mas Qui, me gusta la tecnología y aprender de ella, me gusta saber como funcionan las cosas y comprenderlas.
                    </p>
                </div>
            </div>

            <div class="col s12 ">
                <div class="card yellow">

                    <div class="card-content">

                        <p>
                            Me gustan los juegos de nintendo como Pokemon, Super Mario bros, Zelda. igual los juegos de accion y de shooter como Call of duty y otros mas
                        </p>
                    </div>
                </div>
            </div>
        </div>


        



        <figure>
            <img src="https://th.bing.com/th/id/OIP.5jpDufeIX3hgzmA922LQdQHaEK?pid=ImgDet&rs=1"
                 alt="Usabilidad">
            <figcaption>Figura de muestra XD</figcaption>
        </figure>
        <p2>
            serio
            <input type="range" min="1" , max="10" />
            divertido
            <br />maduro
            <input type="range" min="1" , max="10" />
            joven
            <br />

            <a>uacam</a>
            <a href="" ""="">Facultad de Ingeniería</a>
            <a href="https://www.uacam.mx/">ISC</a>
            <hr />
        </p2>
       

        <h4>Redes sociales</h4>
        <a class="waves-effect waves-light btn-small light-blue darken-4"><i class="material-icons left">facebook</i></a>
        <a class="waves-effect waves-light btn-small  blue"><i class="material-icons right">mail</i></a>
        <a class="waves-effect waves-light btn-small purple"><i class="material-icons right">photo_camera</i></a>     

