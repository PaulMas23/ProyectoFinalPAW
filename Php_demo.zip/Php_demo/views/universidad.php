<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<div class="news-cards">
    <div>
        <img src="./images/rector.png" alt=""  />
        <h3>Lorem, ipsum dolor.</h3>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam
            dolore fugit esse corporis nesciunt minima doloremque modi mollitia
            rerum, similique optio eligendi itaque amet qui ullam vel incidunt
            asperiores fuga?
        </p>
        <a href="#">Leer ... <i class="fas fa-angle-double-right"></i></a>
    </div>
    <div>
        <img src="./images/uac2.jpeg" alt="" />
        <h3>Lorem, ipsum dolor.</h3>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam
            dolore fugit esse corporis nesciunt minima doloremque modi mollitia
            rerum, similique optio eligendi itaque amet qui ullam vel incidunt
            asperiores fuga?
        </p>
        <a href="#">Leer ... <i class="fas fa-angle-double-right"></i></a>
    </div>
    <div>
        <img src="./images/uac3.jpeg" alt="" />
        <h3>Lorem, ipsum dolor.</h3>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam
            dolore fugit esse corporis nesciunt minima doloremque modi mollitia
            rerum, similique optio eligendi itaque amet qui ullam vel incidunt
            asperiores fuga?
        </p>
        <a href="#">Leer ... <i class="fas fa-angle-double-right"></i></a>
    </div>
    
    
