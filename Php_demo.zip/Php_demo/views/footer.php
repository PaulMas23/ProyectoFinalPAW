<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!-- pie de paginna -->
    <footer class="page-footer black">
        <div class="container">
            <div class="row">
                <div class="col l6 s12">
                    <h5 class="white-text">Paul Mas Qui</h5>
                    <p class="grey-text text-lighten-4">Estudiante de la facultad de ingeniería, esto es una practica de pagina web</p>
                </div>
                <div class="col l4 offset-l2 s12">
                    <h5 class="white-text">Redes Sociales</h5>
                    <ul>
                        <li><a class="grey-text text-lighten-3" href="https://www.facebook.com/PaulMasQui/">Facebook</a></li>
                        <li><a class="grey-text text-lighten-3" href="https://www.twitter.com/PaulMas17/">Twitter</a></li>
                        <li><a class="grey-text text-lighten-3" href="https://www.instagram.com/itsmepool/" >Instagram</a></li>
                        
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <div class="container">
                © 2014 Copyright Alumno Paul Enrique Mas Qui PAW
                
                <a class="grey-text text-lighten-4 right" href="#!"><i class="material-icons prefix" href="https://www.facebook.com/PaulMasQui/">facebook</i></a>
                <a class="grey-text text-lighten-4 right" href="#!"><i class="material-icons prefix" href="https://www.twitter.com/PaulMas17/">camera_alt</i></a>
                <a class="grey-text text-lighten-4 right" href="#!"><i class="material-icons prefix" href="https://www.instagram.com/itsmepool/">alternate_email</i></a>
            </div>
        </div>
    </footer>