<?php


?>

<div class="container">
    <div class="column">
        <div class="box">
            <figure class="image is-240x240">
                <img src="images/error1.jpg">
            </figure>
            <p class="title is-5">Acceso no permitido </p>
            <p class="subtitle">Usted no tiene acceso a la página solicitada</p>
            <br>
            <p>Siga los pasos del Manual de operación para el correcto funcionamiento del sistema. Gracias por su apoyo</p>
            <br>
            <p>La página solicitad no esta disponible para su consulta</p>
            <button class="btn waves-effect waves-light" type="submit" name="action">
                        <a href="?menu=inicio">
                            <i class="material-icons right white-text">Regresar</i></a>
                    </button>  
        </div>
    </div>
</div>
<br>